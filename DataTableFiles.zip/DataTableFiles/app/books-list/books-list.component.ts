import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-books-list',
  templateUrl: './books-list.component.html',
  styleUrls: ['./books-list.component.css']
})
export class BooksListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  
  datas: any[] = [
    
            {"name": "The Godfather", "price": 10, "author": "Mario Puzo"},
    
            {"name": "The Fellowship of the Ring", "price": 15, "author": "J.R.R. Tolkien"},
    
            {"name": "Harry Potter and the Deathly Hallows", "price": 20, "author": "J.K. Rowling  "},
            {"name": "Game of thrones", "price": 20, "author": "Ice and fire"},  
            {"name": "Peaky Blinders", "price": 10, "author": "Ice and fire"},  
            {"name": "Breaking bad", "price": 15, "author": "Ice and fire"},  
            {"name": "DARK", "price": 5, "author": "Ice and fire"} , 
            {"name": "The Godfather", "price": 10, "author": "Mario Puzo"},
    
            {"name": "The Fellowship of the Ring", "price": 15, "author": "J.R.R. Tolkien"},
    
            {"name": "Harry Potter and the Deathly Hallows", "price": 20, "author": "J.K. Rowling  "},
            {"name": "Game of thrones", "price": 20, "author": "Ice and fire"},  
            {"name": "Peaky Blinders", "price": 10, "author": "Ice and fire"},  
            {"name": "Breaking bad", "price": 15, "author": "Ice and fire"},  
            {"name": "DARK", "price": 5, "author": "Ice and fire"} ,
            {"name": "The Godfather", "price": 10, "author": "Mario Puzo"},
    
            {"name": "The Fellowship of the Ring", "price": 15, "author": "J.R.R. Tolkien"},
    
            {"name": "Harry Potter and the Deathly Hallows", "price": 20, "author": "J.K. Rowling  "},
            {"name": "Game of thrones", "price": 20, "author": "Ice and fire"},  
            {"name": "Peaky Blinders", "price": 10, "author": "Ice and fire"},  
            {"name": "Breaking bad", "price": 15, "author": "Ice and fire"},  
            {"name": "DARK", "price": 5, "author": "Ice and fire"} ,
            {"name": "The Godfather", "price": 10, "author": "Mario Puzo"},
    
            {"name": "The Fellowship of the Ring", "price": 15, "author": "J.R.R. Tolkien"},
    
            {"name": "Harry Potter and the Deathly Hallows", "price": 20, "author": "J.K. Rowling  "},
            {"name": "Game of thrones", "price": 20, "author": "Ice and fire"},  
            {"name": "Peaky Blinders", "price": 10, "author": "Ice and fire"},  
            {"name": "Breaking bad", "price": 15, "author": "Ice and fire"},  
            {"name": "DARK", "price": 5, "author": "Ice and fire"} ,
            {"name": "The Godfather", "price": 10, "author": "Mario Puzo"},
    
            {"name": "The Fellowship of the Ring", "price": 15, "author": "J.R.R. Tolkien"},
    
            {"name": "Harry Potter and the Deathly Hallows", "price": 20, "author": "J.K. Rowling  "},
            {"name": "Game of thrones", "price": 20, "author": "Ice and fire"},  
            {"name": "Peaky Blinders", "price": 10, "author": "Ice and fire"},  
            {"name": "Breaking bad", "price": 15, "author": "Ice and fire"},  
            {"name": "DARK", "price": 5, "author": "Ice and fire"}     
    
        ];
       
        cols: any[] = [
          { field: 'name', header: 'Name' },
          {field: 'author', header: 'Author' },
          { field: 'price', header: 'Price' } 

        ]

}
