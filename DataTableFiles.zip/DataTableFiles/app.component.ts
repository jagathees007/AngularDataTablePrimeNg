import { Component } from '@angular/core';
import { RouteConfigLoadEnd, Router } from '@angular/router';
//Reference URL
//https://dzone.com/articles/angular8-primeng-tutorial-implement-data-table-com
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'AngularDataTable';
  ShowBooksList : boolean;
  constructor(private router: Router){

  }
  
  LoadBooks():void{
    this.router.navigate(['BooksList'])
  }

}
